"""Top-level package for Webex Bot."""

__author__ = """Finbarr Brady"""
__version__ = '1.0.5'
